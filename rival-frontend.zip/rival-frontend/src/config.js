// API Configuration
export const API_BASE_URL = 'https://g8h3ilc79pek.manus.space/api'

